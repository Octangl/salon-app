<!DOCTYPE html>
<html lang="en" >

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Appointment Booked - Octangl</title>
  <title>Octangl &mdash;Book Appointments With Proffesional Hair Salons</title>
	<meta name="description" content="Largest Salon Directory and Booking Platform In Nigeria">
	<meta name="keywords" content="hair salon, best salons in Owerri, make my hair, where can i make my hair, salons in owerri, owerri">
  <link rel='stylesheet' href='assets/css/bootstrap/bootstrap.min.css'>
  <link rel="stylesheet" href="assets/css/loader-css/style.css">
  

  
</head>

<body>

  <h1>Appointment Booked Successfully!</h1>

<div class="circle-loader">
  <div class="checkmark draw"></div>
</div>

<p><button id="toggle" type="button" class="btn btn-success">Toggle Completed</button></p>
  
  <script src='assets/js/jquery.min.js'></script>
  <script  src='assets/js/main.js'></script>
  




</body>

</html>
